
        <li class="nav-item">
          <a class="nav-link nav-color" href="">
            <i class="fa fa-tachometer menu-icon "></i>
            <span class="menu-title">DASHBOARD</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="ui-basic">
            <i class="menu-icon"><iconify-icon icon="carbon:user-settings"></iconify-icon></i>
            
            <span class="menu-title">USER ACCOUNT</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="form-elements">
            <i class="fa fa-user menu-icon"></i>
            <span class="menu-title">CUSTOMER</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="charts">
            <i class="menu-icon"><iconify-icon icon="fa6-solid:dolly"></iconify-icon></i>
            <span class="menu-title">SUPPLIER</span>
          </a>          
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="tables">
            <i class="icon-grid menu-icon"></i>
            <span class="menu-title">CATEGORY</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="icons">
            <i class="menu-icon"><iconify-icon icon="mdi:shovel"></iconify-icon></i>
            <span class="menu-title">PRODUCT</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="auth">
            <i class=" menu-icon fa fa-pencil-square-o"></i>
            <span class="menu-title">RESERVATIONS</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" data-toggle="collapse" href="" aria-expanded="false" aria-controls="error">
            <i class="menu-icon fa fa-truck"></i>
            <span class="menu-title">DELIVERIES</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-color" href="">
            <i class="icon-paper menu-icon"></i>
            <span class="menu-title">REPORTS</span>
          </a>
        </li>
